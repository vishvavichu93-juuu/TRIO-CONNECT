---
name: Campus Match & Housing
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  container-max-w: 1280px
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
---

## Brand & Style

This design system powers a student-first college housing and roommate matchmaking platform built around the premise: "Find the Right Roommate, Not Just a Room."

The visual language bridges energetic peer-to-peer social connectivity with institutional safety and transactional clarity. It speaks directly to Gen Z college students navigating independent living for the first time, as well as discerning university parents who prioritize safety and verification.

### Design Movement
The aesthetic synthesizes **Modern SaaS** with **Soft Tech / Expressive Minimalism**:
- Pristine, high-clarity white and cool-slate surfaces to communicate reliability and structure.
- Hyper-saturated indigo and electric purple accents inject youthful momentum and community vitality.
- Tactile, rounded micro-interactions and soft atmospheric glows soften institutional rigidity without devolving into childish or casual territory.
- Prominent verification anchors (clean emerald iconography and badges) foster immediate safety, trust, and validation.

## Colors

The color palette is built upon high-contrast readability, energetic digital primaries, and contextual semantic anchors.

### Core Roles
- **Primary (`#4F46E5` / Indigo-600)**: The core brand anchor. Represents intelligence, digital networking, and decisive action. Used for primary callouts, main action buttons, active navigation states, and identity elements.
- **Secondary (`#7C3AED` / Electric Violet-600)**: Companion accent driving discovery, compatibility highlights, peer vibe tags, and celebratory match states.
- **Tertiary (`#10B981` / Emerald-500)**: Reserved explicitly for authenticity signals: .edu verified students, verified leases, background checks, and active security validations.
- **Accent Highlight (`#F59E0B` / Amber-500)**: Denotes compatibility percentages, top-rated property honors, urgency banners, and mutual lifestyle affinities.
- **Neutral Core (`#0F172A` / Slate-900)**: High-density slate for crisp typography, grounding visual elements away from pure `#000000` to maintain approachable contrast.

### Surface Architecture
- **App Canvas**: `#F8FAFC` (Slate-50) creates a soft, eye-resting background across expansive viewports.
- **Card Surface**: Pure `#FFFFFF` ensures card elevations and content containers lift cleanly from the background.
- **Structural Dividers**: `#E2E8F0` (Slate-200) for clean, lightweight hairline dividers (1px) preserving modular balance.

## Typography

**Plus Jakarta Sans** is the single typographic voice across all viewport layers. Its contemporary geometry, generous x-height, and sculpted apertures provide pristine legibility across small UI labels (e.g., campus distance meters, compatibility pills) while conveying energetic optimism in large display sizes.

### Usage Directives
- **Headlines (`display-lg` down to `headline-md`)**: Rendered in Bold (`700`) or Extra Bold (`800`) with tight tracking to generate an assertive, punchy editorial feel.
- **Body Copy**: Standardized in Slate-700 (`#334155`) for high contrast that remains softer than raw black, reducing eye strain during deep listing evaluations.
- **Labels & Tags**: Utilize medium and semibold weights (`600`/`700`). Caps are reserved exclusively for `label-sm` badges when tracking is expanded (`letterSpacing: 0.04em`) to ensure legibility on dense interfaces.

## Layout & Spacing

The layout philosophy leverages an 8pt-based rhythmic scale configured into a structured 12-column responsive fluid grid.

### Breakpoints & Grids
- **Desktop (≥1200px)**: 12-column grid with a maximum content constraint of `1280px`. Column gutter is set to `2rem` (`space-xl`), side margins to `2rem` (`gutter-desktop`). Accommodates split views (e.g., sticky map viewport alongside dual-card listing flows).
- **Tablet (768px – 1199px)**: 8-column layout with `1.5rem` gutters and `1.5rem` margins. Filters collapse into sliding horizontal pill bars or off-canvas drawers.
- **Mobile (<768px)**: 4-column layout with `1rem` gutters and `1rem` page margins. Actions, match decks, and listing cards reflow to 100% full-width stacked layouts.

### Vertical Rhythm
- Card internal padding is locked to `1.25rem` (compact) or `1.5rem` (standard).
- Section groupings maintain `space-2xl` (48px) separating headers and major listing carousels, maintaining an uncluttered, spacious campus experience.

## Elevation & Depth

Visual hierarchy uses a refined combination of subtle ambient shadows and low-contrast outlines. Strong black dropshadows are explicitly avoided in favor of indigo- and slate-tinted ambient glows that evoke lightness and modern polish.

### Elevation Levels
- **Level 0 (Flat)**: Elements resting directly on canvas. Outlined with `1px solid #E2E8F0`. Used for nested profile sub-sections and standard unselected inputs.
- **Level 1 (Resting Card / Ambient Lift)**: `box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)`. Combined with a crisp border: `1px solid #F1F5F9`. Applied to listing cards, roommate cards, and filter bars.
- **Level 2 (Hover & Floating Elements)**: `box-shadow: 0 12px 32px -4px rgba(79, 70, 229, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.04)`. Used when hovering cards, elevated dropdown sheets, and active interactive elements. The subtle indigo tint communicates actionable depth.
- **Level 3 (Modals & Overlays)**: `box-shadow: 0 24px 48px -12px rgba(15, 23, 42, 0.18)`. Supported by a backdrop blur scrim: `backdrop-filter: blur(8px); background-color: rgba(15, 23, 42, 0.4)`.

## Shapes

The interface embraces a rounded, friendly, and approachable geometry (`roundedness: 2`). Sharp corners are deliberately eliminated to convey warmth, safety, and modern social energy.

### Application Specs
- **Micro UI (Checkboxes, mini-toggles)**: `rounded-md` (6px–8px).
- **Buttons, Inputs & Pill Tabs**: `rounded-full` (9999px) for search bars, category chips, and key action pills; `rounded-lg` (12px) for form inputs.
- **Listing & Profile Cards**: `rounded-2xl` (16px to 20px). Softened silhouettes frame photos cleanly without clipping important contextual details.
- **Modals & Slide-overs**: `rounded-3xl` (24px) for desktop dialogs and mobile bottom sheets.

## Components

### Buttons
- **Primary CTA**: Background `#4F46E5`, text `#FFFFFF`, font `label-lg`, padding `12px 24px`, border-radius `12px` or `rounded-full`. Hover: `#4338CA` with subtle vertical translation (`translate-y-[-1px]`) and Level 2 indigo shadow.
- **Secondary / Soft Action**: Background `#EEF2FF` (Indigo-50), text `#4F46E5`, hover background `#E0E7FF`.
- **Outline / Neutral**: Background `#FFFFFF`, border `1.5px solid #E2E8F0`, text `#0F172A`, hover background `#F8FAFC`.

### Specialized Badges & Pills
- **Verified Student Badge**: Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`. Includes a solid `#10B981` checkmark icon. Compact sizing using `label-sm`.
- **Verified Property Badge**: Background `#F0FDF4`, text `#166534`, border `1px solid #BBF7D0`. Shields and building icons used alongside verification text.
- **Compatibility Score Pill**: Pill-shaped container (`rounded-full`) with a subtle gradient or solid tint: `#FAF5FF` (Purple-50) border `1px solid #E9D5FF`. Text `#7C3AED` featuring a bold numeric indicator (e.g., "94% Match").

### Chips & Filter Pills
- **Filter Chip (Default)**: Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#475569`, border-radius `9999px`, padding `8px 16px`.
- **Filter Chip (Active)**: Background `#4F46E5`, border `1px solid #4F46E5`, text `#FFFFFF`, font weight `600`. Smooth 150ms ease-in-out transition.

### Input Fields
- **Standard Input**: Height `48px`, background `#FFFFFF`, border `1.5px solid #E2E8F0`, border-radius `12px`, padding `0 16px`, typography `body-md`.
- **Focus State**: Border color `#4F46E5`, box-shadow `0 0 0 4px rgba(79, 70, 229, 0.12)`, outline none.
- **Search Header Bar**: Extended height `56px`, pill-shaped (`rounded-full`), integrated inline icon prefixes, background `#FFFFFF`, Level 1 ambient elevation.

### Roommate & Housing Cards
- Constructed with `rounded-2xl` (18px) borders, surface `#FFFFFF`, and Level 1 elevation.
- Image aspect ratios fixed at 4:3 or 16:10 with top border radiuses matched seamlessly to card bounds.
- Profile cards prominently position the Compatibility Score Pill on the upper right corner, with student verification badges anchored directly below the student's name and graduation year.